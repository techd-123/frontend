import React, { useState } from 'react';
import Header from '../../components/common/Header';
import Footer from '../../components/common/Footer';
import Button from '../../components/ui/Button';
import SearchView from '../../components/ui/SearchView';
import EditText from '../../components/ui/EditText';
import Dropdown from '../../components/ui/Dropdown';

const Home = () => {
  const [selectedVendor, setSelectedVendor] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [userName, setUserName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [selectedVendorType, setSelectedVendorType] = useState('');

  const vendorOptions = [
    { label: 'Venues', value: 'venues' },
    { label: 'Photographers', value: 'photographers' },
    { label: 'Planners', value: 'planners' },
    { label: 'Caterers', value: 'caterers' },
    { label: 'Car Rentals', value: 'car-rentals' },
    { label: 'Makeup Artist', value: 'makeup-artist' },
    { label: 'Entertainments', value: 'entertainments' },
    { label: 'Tailorings', value: 'tailorings' }
  ];

  const locationOptions = [
    { label: 'Kochi', value: 'kochi' },
    { label: 'Thiruvananthapuram', value: 'thiruvananthapuram' },
    { label: 'Kozhikode', value: 'kozhikode' },
    { label: 'Alappuzha', value: 'alappuzha' }
  ];

  const vendorTypeOptions = [
    { label: 'Wedding Planners', value: 'wedding-planners' },
    { label: 'Event Photographers', value: 'event-photographers' },
    { label: 'Catering Services', value: 'catering-services' },
    { label: 'Venue Booking', value: 'venue-booking' }
  ];

  const handleSearch = (query) => {
    setSearchQuery(query);
  };

  const handleContactSubmit = () => {
    console.log('Contact form submitted:', { userName, mobileNumber, selectedVendorType });
  };

  return (
    <div className="flex flex-col min-h-screen bg-global-6">
      <Header />
      <main className="flex-1">
        {/* Enhanced Hero Section */}
        <section className="w-full bg-[linear-gradient(125deg,#261539f4_0%,#511f5a_50%,#c2639d_100%)] shadow-[0px_4px_4px_#0000003f] relative overflow-hidden">
          {/* Background decorative elements */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-20 left-10 w-32 h-32 bg-white rounded-full blur-3xl"></div>
            <div className="absolute bottom-20 right-10 w-40 h-40 bg-pink-300 rounded-full blur-3xl"></div>
          </div>
          
          <div className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row items-center justify-between py-16 sm:py-20 lg:py-28 gap-12 lg:gap-16">
              {/* Enhanced Left Content */}
              <div className="w-full lg:w-1/2 text-center lg:text-left space-y-8">
                {/* Main Heading with improved typography */}
                <div className="space-y-6">
                  <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold font-poppins leading-[1.1] text-global-7 tracking-tight">
                    One platform.
                    <br />
                    <span className="bg-gradient-to-r from-pink-200 to-white bg-clip-text text-transparent">
                      Many Events
                    </span>
                    <br />
                    <span className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-normal">
                      Endless Possibilities.
                    </span>
                  </h1>
                  
                </div>
                
                {/* Enhanced Search Container */}
                <div className="relative">
                  <div className="bg-gradient-to-r from-purple-400/20 to-pink-400/20 rounded-3xl p-1 shadow-2xl backdrop-blur-sm">
                    <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 sm:p-8 shadow-inner">
                      <div className="text-center mb-6">
                        <h3 className="text-xl sm:text-2xl font-semibold text-gray-800 mb-2">
                          Find top-rated vendors for every vibe
                        </h3>
                      </div>
                      
                      {/* Improved Mobile-First Search Layout */}
                      <div className="space-y-4">
                        {/* Top Row: Vendor and Location Selection */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Dropdown
                              placeholder="Select Vendors"
                              options={vendorOptions}
                              value={selectedVendor}
                              onChange={setSelectedVendor}
                              rightImage={{
                                src: "/images/img_arrow_down.svg",
                                width: 20,
                                height: 20
                              }}
                              className="w-full border-2 border-gray-200 rounded-2xl bg-white text-gray-800 hover:border-purple-300 focus:border-purple-500 transition-all duration-300 shadow-sm hover:shadow-md"
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Dropdown
                              placeholder="Choose Location"
                              options={locationOptions}
                              value={selectedLocation}
                              onChange={setSelectedLocation}
                              rightImage={{
                                src: "/images/img_arrow_down.svg",
                                width: 20,
                                height: 20
                              }}
                              className="w-full border-2 border-gray-200 rounded-2xl bg-white text-gray-800 hover:border-purple-300 focus:border-purple-500 transition-all duration-300 shadow-sm hover:shadow-md"
                            />
                          </div>
                        </div>
                        
                        {/* Bottom Row: Search Input with Enhanced Button */}
                        {/* <div className="space-y-2"> */}
                          {/* <div className="flex gap-3"> */}
                            {/* <div className="flex-1">
                              <SearchView
                                placeholder="Search events, venues, services..."
                                onSearch={handleSearch}
                                leftImage={{
                                  src: "/images/img_search.svg",
                                  width: 20,
                                  height: 20
                                }}
                                className="bg-white border-2 border-gray-200 rounded-2xl px-5 py-4 text-gray-800 placeholder-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500 focus:ring-opacity-20 hover:border-purple-300 transition-all duration-300 shadow-sm hover:shadow-md text-base sm:text-lg"
                              />
                            </div> */}
                            {/* <Button
                              onClick={() => handleSearch(searchQuery)}
                              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white border-0 rounded-2xl px-8 py-4 text-base font-semibold uppercase tracking-wide hover:from-purple-700 hover:to-pink-700 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl min-w-[120px] whitespace-nowrap"
                              size="medium"
                            >
                              Search
                            </Button> */}
                          {/* </div> */}
                        {/* </div> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Enhanced Right Images Grid */}
              <div className="w-full lg:w-1/2 flex justify-center lg:justify-end">
                <div className="relative max-w-md lg:max-w-lg">
                  {/* Top featured image */}
                  <div className="mb-6 flex justify-center">
                    <div className="relative group">
                      <img 
                        src="/images/img_rectangle_6465.png" 
                        alt="Featured Event" 
                        className="w-32 h-24 sm:w-40 sm:h-32 lg:w-48 lg:h-36 object-cover rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                  </div>
                  
                  {/* Main image grid */}
                  <div className="space-y-4">
                    {/* First row - 3 images */}
                    <div className="flex justify-center gap-3 sm:gap-4">
                      {[
                        "/images/img_rectangle_6458.png",
                        "/images/img_rectangle_6456.png",
                        "/images/img_rectangle_6457.png"
                      ]?.map((image, index) => (
                        <div key={index} className="relative group">
                          <img 
                            src={image} 
                            alt={`Event Gallery ${index + 1}`}
                            className="w-20 h-24 sm:w-24 sm:h-32 lg:w-28 lg:h-36 object-cover rounded-xl shadow-lg hover:shadow-xl transition-all duration-500 group-hover:scale-110 group-hover:-rotate-2"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-purple-600/20 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        </div>
                      ))}
                    </div>
                    
                    {/* Second row - 4 images */}
                    <div className="flex justify-center gap-2 sm:gap-3">
                      {[
                        "/images/img_rectangle_6461.png",
                        "/images/img_rectangle_6462.png",
                        "/images/img_rectangle_6460.png",
                        "/images/img_rectangle_6459.png"
                      ]?.map((image, index) => (
                        <div key={index} className="relative group">
                          <img 
                            src={image} 
                            alt={`Event Gallery ${index + 5}`}
                            className="w-16 h-20 sm:w-20 sm:h-24 lg:w-22 lg:h-28 object-cover rounded-lg shadow-md hover:shadow-lg transition-all duration-500 group-hover:scale-110 group-hover:rotate-1"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-pink-600/20 to-transparent rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Floating stats or badges */}
                  <div className="absolute -bottom-4 -right-4 bg-white rounded-2xl shadow-xl p-4 hidden lg:block">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">1000+</div>
                      <div className="text-sm text-gray-600">Happy Clients</div>
                    </div>
                  </div>
                  
                  <div className="absolute -top-4 -left-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-2xl shadow-xl p-3 hidden lg:block">
                    <div className="text-center">
                      <div className="text-lg font-bold">500+</div>
                      <div className="text-xs">Vendors</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Enhanced Build Your Vendor Team Section */}
        <section className="w-full py-16 sm:py-20 lg:py-24">
          <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-semibold font-poppins leading-tight text-center capitalize text-global-1 mb-12 sm:mb-16">
              Build your vendor team
            </h2>
            
            {/* Enhanced Vendor Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8 mb-6 sm:mb-8">
              {[
                { image: "/images/img_rectangle_6468.png", title: "Venues" },
                { image: "/images/img_rectangle_6469.png", title: "Photographers" },
                { image: "/images/img_rectangle_6470.png", title: "Planners" },
                { image: "/images/img_rectangle_6471.png", title: "Caterers" }
              ]?.map((vendor, index) => (
                <div key={index} className="group">
                  <div className="relative w-full h-40 sm:h-52 lg:h-64 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer transform hover:scale-105">
                    <img 
                      src={vendor?.image} 
                      alt={vendor?.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-global-4 via-transparent to-transparent opacity-80"></div>
                    <div className="absolute inset-0 bg-global-7 bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center">
                      <Button
                        onClick={() => console.log(`Selected vendor: ${vendor?.title}`)}
                        className="bg-global-7 text-global-4 px-6 py-3 rounded-xl shadow-lg text-base sm:text-lg font-semibold capitalize transform translate-y-8 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-global-3 hover:text-global-7"
                        size="medium"
                      >
                        {vendor?.title}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Second Row */}
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8 mb-8 sm:mb-12">
              {[
                { image: "/images/img_rectangle_6472.png", title: "Car Rentals" },
                { image: "/images/img_rectangle_6473.png", title: "Makeup Artist" },
                { image: "/images/img_rectangle_6474.png", title: "Entertainments" },
                { image: "/images/img_rectangle_6475.png", title: "Tailorings" }
              ]?.map((vendor, index) => (
                <div key={index} className="group">
                  <div className="relative w-full h-40 sm:h-52 lg:h-64 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer transform hover:scale-105">
                    <img 
                      src={vendor?.image} 
                      alt={vendor?.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-global-4 via-transparent to-transparent opacity-80"></div>
                    <div className="absolute inset-0 bg-global-7 bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center">
                      <Button
                        onClick={() => console.log(`Selected vendor: ${vendor?.title}`)}
                        className="bg-global-7 text-global-4 px-6 py-3 rounded-xl shadow-lg text-base sm:text-lg font-semibold capitalize transform translate-y-8 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-global-3 hover:text-global-7"
                        size="medium"
                      >
                        {vendor?.title}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="text-center">
              <button className="text-lg font-medium font-poppins text-global-4 hover:text-global-2 transition-colors duration-200 underline decoration-2 underline-offset-4 hover:decoration-global-2">
                Explore more vendors
              </button>
            </div>
          </div>
        </section>

        {/* Enhanced Why Plan IT Here Section */}
        <section className="w-full bg-global-4 py-16 sm:py-20 lg:py-24">
          <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-12 lg:gap-16 items-center">
              {/* Left Content */}
              <div className="w-full lg:w-3/5">
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-medium font-poppins leading-tight text-center lg:text-left capitalize text-global-1 mb-8 sm:mb-10">
                  Why Plan IT here ?
                </h2>
                
                <p className="text-base sm:text-lg lg:text-xl font-normal font-poppins leading-relaxed text-left text-global-5 mb-12 sm:mb-16">
                  Lorem ipsum dolor sit amet consectetur. Feugiat dictumst erat turpis libero diam lectus urna pulvinar metus. Arcu euismod semper sed donec morbi integer. Dui massa porttitor arcu amet nisl mauris tincidunt nisi at. Vestibulum sit vel amet sed aliquet consectetur in.
                </p>
                
                {/* Enhanced Features Grid */}
                <div className="space-y-8 sm:space-y-10 lg:space-y-12">
                  {/* First Row */}
                  <div className="flex flex-col lg:flex-row gap-6 lg:gap-8">
                    <div className="flex gap-5 lg:gap-6 flex-1 p-4 rounded-xl hover:bg-global-6 hover:shadow-lg transition-all duration-300">
                      <div className="bg-global-2 rounded-2xl p-4 lg:p-5 flex items-center justify-center shadow-md">
                        <img 
                          src="/images/img_component_1.svg" 
                          alt="Dashboard" 
                          className="w-8 h-6 sm:w-10 sm:h-7 lg:w-12 lg:h-8"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg sm:text-xl font-semibold font-poppins leading-tight text-global-3 mb-2 lg:mb-3">
                          Personalized Dashboard
                        </h3>
                        <p className="text-base sm:text-lg font-normal font-poppins leading-relaxed text-global-5">
                          Organize every wedding detail
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex gap-5 lg:gap-6 flex-1 p-4 rounded-xl hover:bg-global-6 hover:shadow-lg transition-all duration-300">
                      <div className="bg-global-3 rounded-2xl p-4 lg:p-5 flex items-center justify-center shadow-md">
                        <img 
                          src="/images/img_background.svg" 
                          alt="Budget Tracker" 
                          className="w-10 h-10 sm:w-14 sm:h-14 lg:w-16 lg:h-16"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg sm:text-xl font-semibold font-poppins leading-tight text-global-3 mb-2 lg:mb-3">
                          Budget & Expense Tracker
                        </h3>
                        <p className="text-base sm:text-lg font-normal font-poppins leading-relaxed text-global-5">
                          Organize every wedding detail
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Second Row */}
                  <div className="flex flex-col lg:flex-row gap-6 lg:gap-8">
                    <div className="flex gap-5 lg:gap-6 flex-1 p-4 rounded-xl hover:bg-global-6 hover:shadow-lg transition-all duration-300">
                      <div className="bg-global-3 rounded-2xl p-4 lg:p-5 flex items-center justify-center shadow-md">
                        <img 
                          src="/images/img_background_white_a700.svg" 
                          alt="Booking System" 
                          className="w-10 h-10 sm:w-14 sm:h-14 lg:w-16 lg:h-16"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg sm:text-xl font-semibold font-poppins leading-tight text-global-3 mb-2 lg:mb-3">
                          Vendor Booking System
                        </h3>
                        <p className="text-base sm:text-lg font-normal font-poppins leading-relaxed text-global-5">
                          Find top-rated vendors to bring your vision to life.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex gap-5 lg:gap-6 flex-1 p-4 rounded-xl hover:bg-global-6 hover:shadow-lg transition-all duration-300">
                      <div className="bg-global-2 rounded-2xl p-4 lg:p-5 flex items-center justify-center shadow-md">
                        <img 
                          src="/images/img_component_1_white_a700.svg" 
                          alt="Guest List" 
                          className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg sm:text-xl font-semibold font-poppins leading-tight text-global-3 mb-2 lg:mb-3">
                          Guest List & RSVP Manager
                        </h3>
                        <p className="text-base sm:text-lg font-normal font-poppins leading-relaxed text-global-5">
                          Streamline invitations, track responses, and many more.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Third Row */}
                  <div className="flex flex-col lg:flex-row gap-6 lg:gap-8">
                    <div className="flex gap-5 lg:gap-6 flex-1 p-4 rounded-xl hover:bg-global-6 hover:shadow-lg transition-all duration-300">
                      <div className="bg-global-2 rounded-2xl p-4 lg:p-5 flex items-center justify-center shadow-md">
                        <img 
                          src="/images/img_background_white_a700_70x70.svg" 
                          alt="Live Tracking" 
                          className="w-10 h-10 sm:w-14 sm:h-14 lg:w-16 lg:h-16"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg sm:text-xl font-semibold font-poppins leading-tight text-global-3 mb-2 lg:mb-3">
                          Live Tracking & Updates
                        </h3>
                        <p className="text-base sm:text-lg font-normal font-poppins leading-relaxed text-global-5">
                          Organize every wedding detail
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex gap-5 lg:gap-6 flex-1 p-4 rounded-xl hover:bg-global-6 hover:shadow-lg transition-all duration-300">
                      <div className="bg-global-3 rounded-2xl p-4 lg:p-5 flex items-center justify-center shadow-md">
                        <img 
                          src="/images/img_background_70x70.svg" 
                          alt="Live Chat" 
                          className="w-10 h-10 sm:w-14 sm:h-14 lg:w-16 lg:h-16"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg sm:text-xl font-semibold font-poppins leading-tight text-global-3 mb-2 lg:mb-3">
                          Live Chat & Notifications
                        </h3>
                        <p className="text-base sm:text-lg font-normal font-poppins leading-relaxed text-global-5">
                          Get instant updates, important notifications in you fingertips.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Enhanced Right Images */}
              <div className="w-full lg:w-2/5 relative">
                <div className="grid grid-cols-4 gap-2 sm:gap-3">
                  {/* Top row - 4 images */}
                  <img src="/images/img_rectangle_6461_128x108.png" alt="" className="w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                  <img src="/images/img_rectangle_6462.png" alt="" className="w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                  <img src="/images/img_rectangle_6460_128x110.png" alt="" className="w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                  <img src="/images/img_rectangle_6459_128x108.png" alt="" className="w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                  
                  {/* Middle row - 3 images */}
                  <img src="/images/img_rectangle_6458_128x108.png" alt="" className="w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                  <img src="/images/img_rectangle_6456_128x110.png" alt="" className="w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                  <img src="/images/img_rectangle_6457_128x108.png" alt="" className="col-span-2 w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                  
                  {/* Bottom row - 2 images */}
                  <img src="/images/img_rectangle_6469_120x110.png" alt="" className="col-span-2 w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                  <img src="/images/img_rectangle_6468_122x108.png" alt="" className="w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                  <img src="/images/img_rectangle_6470_122x108.png" alt="" className="w-full h-20 sm:h-24 lg:h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Enhanced Cities We Serve Section */}
        <section className="w-full bg-[linear-gradient(179deg,#511f5ae8_0%,#261539e8_100%)] py-16 sm:py-20 lg:py-24">
          <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-medium font-poppins leading-tight text-center capitalize text-global-7 mb-12 sm:mb-16">
              Cities we serve
            </h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-12 sm:mb-16">
              {[
                { image: "/images/img_rectangle_6480.png", city: "Kochi" },
                { image: "/images/img_rectangle_6480_160x240.png", city: "Thiruvananthapuram" },
                { image: "/images/img_rectangle_6480_1.png", city: "Kozhikode" },
                { image: "/images/img_rectangle_6480_2.png", city: "Alappuzha" }
              ]?.map((location, index) => (
                <div key={index} className="group">
                  <div className="bg-global-7 rounded-2xl p-2 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer transform hover:scale-105">
                    <img 
                      src={location?.image} 
                      alt={location?.city}
                      className="w-full h-48 sm:h-56 lg:h-64 object-cover rounded-xl mb-4 group-hover:brightness-110 transition-all duration-300"
                    />
                    <p className="text-lg sm:text-xl font-semibold font-poppins leading-tight text-center capitalize text-global-4 pb-4">
                      {location?.city}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <p className="text-base sm:text-lg font-normal font-poppins leading-relaxed text-center capitalize text-global-6">
              We are coming to your place soon
            </p>
          </div>
        </section>

        {/* Vendors We Partnered Section */}
        <section className="w-full bg-global-5 py-8 sm:py-12 md:py-16">
          <div className="w-full max-w-[1206px] mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-[18px] sm:text-[24px] md:text-[30px] lg:text-[36px] font-medium font-poppins leading-[27px] sm:leading-[36px] md:leading-[45px] lg:leading-[54px] text-center capitalize text-global-4 mb-6 sm:mb-8 md:mb-[22px]">
              Vendors we partnered
            </h2>
            
            <div className="flex flex-wrap justify-center items-center gap-6 sm:gap-8 md:gap-10 lg:gap-[40px]">
              {[
                "/images/img_image_628.png",
                "/images/img_image_629.png",
                "/images/img_image_630.png",
                "/images/img_image_628.png",
                "/images/img_image_629.png",
                "/images/img_image_630.png",
                "/images/img_image_628.png"
              ]?.map((image, index) => (
                <img 
                  key={index}
                  src={image} 
                  alt={`Partner ${index + 1}`}
                  className="w-[69px] h-[41px] sm:w-[103px] sm:h-[61px] md:w-[138px] md:h-[82px] object-contain"
                />
              ))}
            </div>
          </div>
        </section>

        {/* Creative Themes Section */}
        <section className="w-full bg-global-5 py-8 sm:py-12 md:py-16">
          <div className="w-full max-w-[1206px] mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-4 md:gap-[16px]">
              {/* Main Creative Theme Card */}
              <div className="w-full lg:w-[48%] relative rounded-[0px_0px_0px_12px] overflow-hidden h-[250px] sm:h-[350px] md:h-[500px]">
                <img 
                  src="/images/img_image_11.png" 
                  alt="Creative Themes" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-[linear-gradient(181deg,#e783b52d_0%,#261539_100%)] flex items-end p-4 sm:p-6 md:p-8">
                  <div className="text-global-7">
                    <h3 className="text-[16px] sm:text-[22px] md:text-[32px] font-bold font-jakarta leading-[19px] sm:leading-[26px] md:leading-[38px] text-left mb-2 sm:mb-3 md:mb-4">
                      Creative Themes for Unforgettable Memories
                    </h3>
                    <p className="text-sm sm:text-base md:text-[16px] font-normal font-figtree leading-[16px] sm:leading-[19px] md:leading-[22px] text-left mb-4 sm:mb-6 md:mb-7">
                      Discover expert advice and creative ideas to help you plan unforgettable Events
                    </p>
                    <div className="flex items-center gap-2 md:gap-[8px]">
                      <span className="text-xs sm:text-sm md:text-[15px] font-bold font-figtree leading-[14px] sm:leading-[16px] md:leading-[19px] text-left uppercase">
                        See More
                      </span>
                      <img 
                        src="/images/img_symbol.svg" 
                        alt="Arrow" 
                        className="w-[6px] h-[6px] sm:w-[9px] sm:h-[9px] md:w-[12px] md:h-[12px]"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Side Theme Cards */}
              <div className="w-full lg:w-[38%] flex gap-4 md:gap-[16px]">
                <div className="flex-1 space-y-4 md:space-y-[16px]">
                  <div className="relative rounded-[0px_0px_12px_12px] overflow-hidden h-[120px] sm:h-[180px] md:h-[242px]">
                    <img 
                      src="/images/img_image_12.png" 
                      alt="Kerala Wedding" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-[linear-gradient(180deg,#e783b52d_0%,#261539_100%)] flex items-end p-3 sm:p-4 md:p-5">
                      <Button 
                        onClick={() => console.log('Kerala Wedding selected')}
                        className="bg-global-7 text-global-7 px-2 py-1 sm:px-3 sm:py-1.5 md:px-[12px] md:py-[6px] rounded-[14px] shadow-[0px_4px_4px_#888888ff] text-xs sm:text-sm md:text-[12px] font-semibold uppercase"
                      >
                        Kerala Wedding
                      </Button>
                    </div>
                  </div>
                  
                  <div className="relative rounded-[0px_0px_12px_12px] overflow-hidden h-[120px] sm:h-[180px] md:h-[242px]">
                    <img 
                      src="/images/img_image_12_476x228.png" 
                      alt="Events" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-[linear-gradient(180deg,#e783b52d_0%,#261539_100%)] flex items-end p-3 sm:p-4 md:p-5">
                      <Button 
                        onClick={() => console.log('Events selected')}
                        className="bg-global-7 text-global-7 px-2 py-1 sm:px-3 sm:py-1.5 md:px-[12px] md:py-[6px] rounded-[14px] shadow-[0px_4px_4px_#888888ff] text-xs sm:text-sm md:text-[12px] font-semibold uppercase"
                      >
                        Events
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="w-[12%] lg:w-[40%]">
                  <div className="relative rounded-[0px_0px_12px_12px] overflow-hidden h-[250px] sm:h-[370px] md:h-[500px]">
                    <img 
                      src="/images/img_image_12_500x228.png" 
                      alt="Baptism" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-[linear-gradient(180deg,#e783b52d_0%,#261539_100%)] flex items-end p-3 sm:p-4 md:p-5">
                      <Button 
                        onClick={() => console.log('Baptism selected')}
                        className="bg-global-7 text-global-7 px-2 py-1 sm:px-3 sm:py-1.5 md:px-[12px] md:py-[6px] rounded-[14px] shadow-[0px_4px_4px_#888888ff] text-xs sm:text-sm md:text-[12px] font-semibold uppercase"
                      >
                        Baptism
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Enhanced Still Confused Section */}
        <section className="w-full bg-global-5 py-16 sm:py-20 lg:py-24">
          <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="border-2 border-global-2 rounded-2xl bg-global-5 p-8 sm:p-10 lg:p-12 shadow-xl">
              <div className="text-center mb-10 sm:mb-12">
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-medium font-poppins leading-tight capitalize text-global-4 mb-6">
                  Still confused on your decision ?
                </h2>
                <p className="text-base sm:text-lg font-normal font-poppins leading-relaxed text-center text-global-2 max-w-4xl mx-auto">
                  One of our team members will give you a quick call to understand what you are looking for and connect you with trusted vendors who fit your needs.
                </p>
              </div>
              
              {/* Enhanced Contact Form */}
              <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">
                <div className="flex-1">
                  <EditText
                    placeholder="Enter your name"
                    value={userName}
                    onChange={setUserName}
                    className="w-full border-2 border-gray-300 rounded-xl bg-global-6 text-global-1 px-4 py-4 focus:border-global-3 focus:ring-2 focus:ring-global-3 focus:ring-opacity-50 transition-all duration-300"
                  />
                </div>
                <div className="flex-1">
                  <EditText
                    placeholder="Enter your mobile number"
                    value={mobileNumber}
                    onChange={setMobileNumber}
                    type="tel"
                    className="w-full border-2 border-gray-300 rounded-xl bg-global-6 text-global-1 px-4 py-4 focus:border-global-3 focus:ring-2 focus:ring-global-3 focus:ring-opacity-50 transition-all duration-300"
                  />
                </div>
                <div className="flex-1">
                  <Dropdown
                    placeholder="Select your vendors"
                    options={vendorTypeOptions}
                    value={selectedVendorType}
                    onChange={setSelectedVendorType}
                    rightImage={{
                      src: "/images/img_arrowdown_black_900.svg",
                      width: 20,
                      height: 20
                    }}
                    className="w-full border-2 border-gray-300 rounded-xl bg-global-6 focus:border-global-3 transition-all duration-300"
                  />
                </div>
                <Button
                  onClick={handleContactSubmit}
                  className="bg-global-3 text-global-7 border-2 border-global-3 rounded-xl px-8 lg:px-12 py-4 text-base lg:text-lg font-semibold capitalize hover:bg-global-2 hover:border-global-2 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
                  size="large"
                >
                  Get Started
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Home;