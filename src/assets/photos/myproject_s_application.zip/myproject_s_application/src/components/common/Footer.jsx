import React from 'react';

const Footer = () => {
  return (
    <footer className="w-full bg-footer-1">
      <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-[15px] sm:py-[20px] md:py-[30px]">
        <div className="flex flex-col lg:flex-row justify-between items-start gap-8 lg:gap-0 mb-[19px] sm:mb-[28px] md:mb-[38px]">
          {/* Brand Section */}
          <div className="flex flex-col gap-[5px] sm:gap-[7px] md:gap-[10px] w-full lg:w-[20%]">
            {/* Logo and Brand Name */}
            <div className="flex items-center gap-3 sm:gap-4 md:gap-6 w-full">
              <div className="relative w-[24px] h-[25px] sm:w-[36px] sm:h-[37px] md:w-[48px] md:h-[50px]">
                <img 
                  src="/images/img_img_20250806_wa0035_50x48.png" 
                  alt="Plan IT Here" 
                  className="w-full h-full rounded-[12px] sm:rounded-[18px] md:rounded-[24px]"
                />
                <img 
                  src="/images/img_group.png" 
                  alt="" 
                  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[16px] h-[16px] sm:w-[24px] sm:h-[24px] md:w-[32px] md:h-[32px]"
                />
              </div>
              <h2 className="text-base sm:text-lg md:text-xl font-bold font-jakarta leading-[20px] sm:leading-[23px] md:leading-[26px] text-global-7">
                Plan IT Here
              </h2>
            </div>

            {/* Company Description */}
            <div className="flex flex-col gap-2 sm:gap-3 md:gap-4 mt-2 sm:mt-4 md:mt-6">
              <p className="text-xs sm:text-sm md:text-sm font-normal font-poppins leading-[16px] sm:leading-[18px] md:leading-[21px] text-global-6">
                Plan IT Here
              </p>
              <p className="text-xs sm:text-sm md:text-sm font-normal font-poppins leading-[16px] sm:leading-[18px] md:leading-[21px] text-global-6">
                organization that leverages.
              </p>
              <img 
                src="/images/img_clip_path_group.svg" 
                alt="Social Media Links" 
                className="w-[84px] h-[15px] sm:w-[126px] sm:h-[22px] md:w-[168px] md:h-[30px] mt-2 sm:mt-3 md:mt-4"
              />
            </div>
          </div>

          {/* Company Links */}
          <div className="flex flex-col gap-[5px] sm:gap-[7px] md:gap-[10px] w-full lg:w-[8%] lg:self-end">
            <h3 className="text-sm sm:text-base md:text-base font-normal font-poppins leading-[18px] sm:leading-[21px] md:leading-[24px] text-global-7">
              Company
            </h3>
            <ul className="flex flex-col gap-[6px] sm:gap-[9px] md:gap-[12px]">
              <li>
                <a 
                  href="#" 
                  className="text-xs sm:text-sm md:text-sm font-normal font-poppins leading-[16px] sm:leading-[18px] md:leading-[21px] text-global-6 hover:text-global-7 transition-colors duration-200"
                >
                  About Us
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  className="text-xs sm:text-sm md:text-sm font-normal font-poppins leading-[16px] sm:leading-[18px] md:leading-[21px] text-global-6 hover:text-global-7 transition-colors duration-200"
                >
                  Vendor login
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  className="text-xs sm:text-sm md:text-sm font-normal font-poppins leading-[16px] sm:leading-[18px] md:leading-[21px] text-global-6 hover:text-global-7 transition-colors duration-200"
                >
                  Contact Us
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;