import React, { useState } from 'react';
import Button from '../ui/Button';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isEventsOpen, setIsEventsOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);

  return (
    <header className="w-full bg-global-6 shadow-sm sticky top-0 z-50">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4 lg:py-6">
          {/* Enhanced Logo */}
          <div className="flex items-center">
            <img 
              src="/images/img_img_20250806_wa0035.png" 
              alt="Plan IT Here Logo" 
              className="w-20 h-7 sm:w-28 sm:h-10 lg:w-36 lg:h-12 hover:scale-105 transition-transform duration-200"
            />
          </div>

          {/* Enhanced Mobile Menu Button */}
          <button 
            className="flex lg:hidden p-3 rounded-xl hover:bg-gray-100 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-global-3" 
            aria-label="Toggle menu"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <svg className={`w-6 h-6 transition-transform duration-300 ${isMenuOpen ? 'rotate-90' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
            </svg>
          </button>

          {/* Enhanced Desktop Navigation */}
          <nav className={`${isMenuOpen ? 'block' : 'hidden'} lg:block absolute lg:relative top-full lg:top-auto left-0 lg:left-auto w-full lg:w-auto bg-global-6 lg:bg-transparent shadow-xl lg:shadow-none z-50 lg:z-auto`}>
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between w-full p-6 lg:p-0 space-y-6 lg:space-y-0 gap-4">
              {/* Main Navigation */}
              <div className="flex flex-col lg:flex-row lg:items-center space-y-4 lg:space-y-0 lg:space-x-8">
                <button 
                  className="text-base font-medium font-poppins text-header-1 hover:text-header-2 transition-all duration-200 py-2 lg:py-0 text-left lg:text-center rounded-lg lg:rounded-none hover:bg-gray-50 lg:hover:bg-transparent px-3 lg:px-0"
                  role="menuitem"
                >
                  Home
                </button>
                
                <div className="relative">
                  <button 
                    className="flex items-center justify-between lg:justify-center gap-2 w-full lg:w-auto text-base font-medium font-poppins text-header-1 hover:text-header-2 transition-all duration-200 py-2 lg:py-0 text-left lg:text-center rounded-lg lg:rounded-none hover:bg-gray-50 lg:hover:bg-transparent px-3 lg:px-0"
                    onClick={() => setIsEventsOpen(!isEventsOpen)}
                    role="menuitem"
                    aria-haspopup="true"
                    aria-expanded={isEventsOpen}
                  >
                    Events
                    <img src="/images/img_arrow_up.svg" alt="" className={`w-4 h-4 transition-transform duration-200 ${isEventsOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isEventsOpen && (
                    <ul className="lg:absolute top-full left-0 mt-2 bg-global-6 border lg:border-gray-200 rounded-xl shadow-lg lg:shadow-xl min-w-[200px] z-10 ml-4 lg:ml-0" role="menu">
                      <li role="menuitem" className="px-4 py-3 text-sm lg:text-base text-header-1 hover:bg-gray-100 hover:text-header-2 cursor-pointer transition-colors duration-200 first:rounded-t-xl last:rounded-b-xl">Wedding</li>
                      <li role="menuitem" className="px-4 py-3 text-sm lg:text-base text-header-1 hover:bg-gray-100 hover:text-header-2 cursor-pointer transition-colors duration-200">Corporate</li>
                      <li role="menuitem" className="px-4 py-3 text-sm lg:text-base text-header-1 hover:bg-gray-100 hover:text-header-2 cursor-pointer transition-colors duration-200 first:rounded-t-xl last:rounded-b-xl">Birthday</li>
                    </ul>
                  )}
                </div>

                <button 
                  className="text-base font-medium font-poppins text-header-1 hover:text-header-2 transition-all duration-200 py-2 lg:py-0 text-left lg:text-center rounded-lg lg:rounded-none hover:bg-gray-50 lg:hover:bg-transparent px-3 lg:px-0"
                  role="menuitem"
                >
                  Vendors
                </button>

                <div className="relative">
                  <button 
                    className="flex items-center justify-between lg:justify-center gap-2 w-full lg:w-auto text-base font-medium font-poppins text-header-1 hover:text-header-2 transition-all duration-200 py-2 lg:py-0 text-left lg:text-center rounded-lg lg:rounded-none hover:bg-gray-50 lg:hover:bg-transparent px-3 lg:px-0"
                    onClick={() => setIsServicesOpen(!isServicesOpen)}
                    role="menuitem"
                    aria-haspopup="true"
                    aria-expanded={isServicesOpen}
                  >
                    Services
                    <img src="/images/img_arrow_up.svg" alt="" className={`w-4 h-4 transition-transform duration-200 ${isServicesOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isServicesOpen && (
                    <ul className="lg:absolute top-full left-0 mt-2 bg-global-6 border lg:border-gray-200 rounded-xl shadow-lg lg:shadow-xl min-w-[200px] z-10 ml-4 lg:ml-0" role="menu">
                      <li role="menuitem" className="px-4 py-3 text-sm lg:text-base text-header-1 hover:bg-gray-100 hover:text-header-2 cursor-pointer transition-colors duration-200 first:rounded-t-xl last:rounded-b-xl">Photography</li>
                      <li role="menuitem" className="px-4 py-3 text-sm lg:text-base text-header-1 hover:bg-gray-100 hover:text-header-2 cursor-pointer transition-colors duration-200">Catering</li>
                      <li role="menuitem" className="px-4 py-3 text-sm lg:text-base text-header-1 hover:bg-gray-100 hover:text-header-2 cursor-pointer transition-colors duration-200 first:rounded-t-xl last:rounded-b-xl">Decoration</li>
                    </ul>
                  )}
                </div>

                <button 
                  className="text-base font-medium font-poppins text-header-1 hover:text-header-2 transition-all duration-200 py-2 lg:py-0 text-left lg:text-center rounded-lg lg:rounded-none hover:bg-gray-50 lg:hover:bg-transparent px-3 lg:px-0"
                  role="menuitem"
                >
                  About
                </button>

                <button 
                  className="text-base font-medium font-poppins text-header-1 hover:text-header-2 transition-all duration-200 py-2 lg:py-0 text-left lg:text-center rounded-lg lg:rounded-none hover:bg-gray-50 lg:hover:bg-transparent px-3 lg:px-0"
                  role="menuitem"
                >
                  Contact
                </button>
              </div>

              {/* Enhanced Auth Section */}
              <div className="flex flex-col lg:flex-row lg:items-center gap-4 lg:gap-6 pt-4 lg:pt-0 border-t lg:border-t-0 border-gray-200">
                <Button
                  variant="outline"
                  size="medium"
                  className="text-button-1 border-2 border-button-text1 hover:bg-button-text1 hover:text-global-7 font-medium"
                  onClick={() => {}}
                >
                  Login
                </Button>
                <span className="text-sm lg:text-base font-normal font-poppins text-center text-header-2">
                  Are you a vendor ?
                </span>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;