import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';

const Dropdown = ({ 
  placeholder = 'Select an option', 
  options = [], 
  value, 
  onChange, 
  rightImage,
  disabled = false,
  className = '',
  ...props 
}) => {
  const [selectedValue, setSelectedValue] = useState(value || '');
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef?.current && !dropdownRef?.current?.contains(event?.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Close dropdown on Escape key
  useEffect(() => {
    const handleEscape = (event) => {
      if (event?.key === 'Escape') {
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, []);

  const handleSelect = (option) => {
    setSelectedValue(option?.value);
    setIsOpen(false);
    if (onChange) {
      onChange(option?.value);
    }
  };

  const selectedOption = options?.find(option => option?.value === selectedValue);

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      <button
        type="button"
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        className={`w-full px-4 py-3 sm:py-4 border-2 rounded-xl bg-global-6 text-left text-base sm:text-lg focus:outline-none focus:ring-2 focus:ring-global-2 focus:ring-opacity-50 transition-all duration-300 min-h-[48px] sm:min-h-[52px] ${disabled ? 'bg-gray-100 cursor-not-allowed' : 'cursor-pointer hover:border-global-3 hover:shadow-md'} ${isOpen ? 'border-global-3 shadow-md' : 'border-gray-300'}`}
        {...props}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
      >
        <div className="flex items-center justify-between">
          <span className={`truncate ${selectedOption ? 'text-global-1' : 'text-gray-500'}`}>
            {selectedOption ? selectedOption?.label : placeholder}
          </span>
          {rightImage && (
            <img 
              src={rightImage?.src} 
              alt="dropdown arrow" 
              className={`flex-shrink-0 ml-2 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
              style={{ width: `${rightImage?.width}px`, height: `${rightImage?.height}px` }}
            />
          )}
        </div>
      </button>
      {/* Enhanced Dropdown Menu */}
      {isOpen && !disabled && (
        <div className="absolute z-50 w-full mt-2 bg-global-6 border-2 border-gray-200 rounded-xl shadow-2xl max-h-60 overflow-auto animate-in fade-in duration-200">
          {options?.length === 0 ? (
            <div className="px-4 py-3 text-gray-500 text-center">No options available</div>
          ) : (
            options?.map((option, index) => (
              <button
                key={index}
                type="button"
                onClick={() => handleSelect(option)}
                className={`w-full px-4 py-3 text-left text-base sm:text-lg transition-colors duration-200 hover:bg-global-4 focus:outline-none focus:bg-global-4 ${selectedValue === option?.value ? 'bg-global-3 text-global-7' : 'text-global-1'} ${index === 0 ? 'rounded-t-xl' : ''} ${index === options?.length - 1 ? 'rounded-b-xl' : ''}`}
              >
                {option?.label}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
};

Dropdown.propTypes = {
  placeholder: PropTypes?.string,
  options: PropTypes?.arrayOf(
    PropTypes?.shape({
      label: PropTypes?.string?.isRequired,
      value: PropTypes?.oneOfType([PropTypes?.string, PropTypes?.number])?.isRequired,
    })
  ),
  value: PropTypes?.oneOfType([PropTypes?.string, PropTypes?.number]),
  onChange: PropTypes?.func,
  rightImage: PropTypes?.shape({
    src: PropTypes?.string?.isRequired,
    width: PropTypes?.number,
    height: PropTypes?.number,
  }),
  disabled: PropTypes?.bool,
  className: PropTypes?.string,
};

export default Dropdown;