import React, { useState } from 'react';
import PropTypes from 'prop-types';

const SearchView = ({ 
  placeholder = 'Search...', 
  onSearch, 
  leftImage, 
  rightImage,
  className = '',
  ...props 
}) => {
  const [searchValue, setSearchValue] = useState('');

  const handleInputChange = (e) => {
    setSearchValue(e?.target?.value);
    if (onSearch) {
      onSearch(e?.target?.value);
    }
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (onSearch) {
      onSearch(searchValue);
    }
  };

  return (
    <form onSubmit={handleSubmit} className={`relative flex items-center ${className} py-0 px-0`}>
      {/* {leftImage && (
        <img 
          src={leftImage?.src} 
          alt="search" 
          className={`absolute left-4 z-10 w-6 h-6 pointer-events-none`}
          style={{ width: `${leftImage?.width}px`, height: `${leftImage?.height}px` }}
        />
      )}
      <input
        type="text"
        value={searchValue}
        onChange={handleInputChange}
        placeholder={placeholder}
        className={`w-full rounded-xl border-2 bg-global-3 text-global-7 placeholder-global-7 placeholder-opacity-70 focus:outline-none focus:ring-2 focus:ring-global-2 focus:ring-opacity-50 transition-all duration-300 text-base sm:text-lg ${leftImage ? 'pl-12' : 'pl-4'} ${rightImage ? 'pr-12' : 'pr-4'} py-3 sm:py-4 hover:shadow-md`}
        {...props}
      />
      {rightImage && (
        <button
          type="submit"
          className="absolute right-4 z-10 w-6 h-6 flex items-center justify-center hover:scale-110 transition-transform duration-200"
        >
          <img 
            src={rightImage?.src} 
            alt="search action" 
            className="w-full h-full"
            style={{ width: `${rightImage?.width}px`, height: `${rightImage?.height}px` }}
          />
        </button>
      )} */}
    </form>
  );
};

SearchView.propTypes = {
  placeholder: PropTypes?.string,
  onSearch: PropTypes?.func,
  leftImage: PropTypes?.shape({
    src: PropTypes?.string?.isRequired,
    width: PropTypes?.number,
    height: PropTypes?.number,
  }),
  rightImage: PropTypes?.shape({
    src: PropTypes?.string?.isRequired,
    width: PropTypes?.number,
    height: PropTypes?.number,
  }),
  className: PropTypes?.string,
};

export default SearchView;