import React, { useState } from 'react';
import PropTypes from 'prop-types';

const EditText = ({ 
  placeholder = '', 
  value, 
  onChange, 
  type = 'text',
  disabled = false,
  required = false,
  className = '',
  ...props 
}) => {
  const [inputValue, setInputValue] = useState(value || '');
  const [isFocused, setIsFocused] = useState(false);

  const handleChange = (e) => {
    setInputValue(e?.target?.value);
    if (onChange) {
      onChange(e?.target?.value);
    }
  };

  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  const baseClasses = `w-full px-4 py-3 sm:py-4 border-2 rounded-xl bg-global-6 text-global-1 placeholder-gray-500 placeholder-opacity-70 transition-all duration-300 text-base sm:text-lg min-h-[48px] sm:min-h-[52px]`;
  
  const focusClasses = isFocused 
    ? 'border-global-3 ring-2 ring-global-3 ring-opacity-50 shadow-md' 
    : 'border-gray-300 hover:border-global-3 hover:shadow-sm';
  
  const inputClasses = `
    ${baseClasses} 
    ${focusClasses}
    ${disabled ? 'bg-gray-100 cursor-not-allowed border-gray-200' : ''} 
    focus:outline-none
    ${className}
  `?.trim()?.replace(/\s+/g, ' ');

  return (
    <input
      type={type}
      value={inputValue}
      onChange={handleChange}
      onFocus={handleFocus}
      onBlur={handleBlur}
      placeholder={placeholder}
      disabled={disabled}
      required={required}
      className={inputClasses}
      {...props}
    />
  );
};

EditText.propTypes = {
  placeholder: PropTypes?.string,
  value: PropTypes?.string,
  onChange: PropTypes?.func,
  type: PropTypes?.string,
  disabled: PropTypes?.bool,
  required: PropTypes?.bool,
  className: PropTypes?.string,
};

export default EditText;