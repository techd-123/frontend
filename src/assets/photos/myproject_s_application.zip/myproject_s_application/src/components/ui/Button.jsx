import React from 'react';
import PropTypes from 'prop-types';

const Button = ({ 
  children, 
  onClick, 
  variant = 'primary', 
  size = 'medium', 
  disabled = false, 
  type = 'button',
  fullWidth = false,
  className = '',
  ...props 
}) => {
  const baseClasses = 'font-medium rounded-xl transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 cursor-pointer transform hover:scale-105 active:scale-95 select-none';
  
  const variants = {
    primary: 'bg-global-3 text-global-7 hover:bg-global-2 focus:ring-global-2 disabled:bg-gray-400 shadow-lg hover:shadow-xl',
    secondary: 'bg-gray-200 text-gray-800 hover:bg-gray-300 focus:ring-gray-300 disabled:bg-gray-100 shadow-md hover:shadow-lg',
    outline: 'border-2 border-button-text1 text-button-1 hover:bg-button-text1 hover:text-global-7 focus:ring-button-text1 disabled:border-gray-200 disabled:text-gray-400 shadow-sm hover:shadow-md',
  };
  
  const sizes = {
    small: 'px-3 py-2 text-sm sm:px-4 sm:py-2.5 sm:text-base min-h-[40px] sm:min-h-[44px]',
    medium: 'px-4 py-3 text-base sm:px-6 sm:py-3.5 sm:text-lg min-h-[44px] sm:min-h-[48px]',
    large: 'px-6 py-4 text-lg sm:px-8 sm:py-4.5 sm:text-xl min-h-[48px] sm:min-h-[52px]',
  };
  
  const buttonClasses = `
    ${baseClasses} 
    ${variants?.[variant]} 
    ${sizes?.[size]} 
    ${fullWidth ? 'w-full' : ''} 
    ${disabled ? 'cursor-not-allowed transform-none hover:scale-100 hover:shadow-none' : ''} 
    ${className}
  `?.trim()?.replace(/\s+/g, ' ');
  
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={buttonClasses}
      {...props}
    >
      {children}
    </button>
  );
};

Button.propTypes = {
  children: PropTypes?.node,
  onClick: PropTypes?.func,
  variant: PropTypes?.oneOf(['primary', 'secondary', 'outline']),
  size: PropTypes?.oneOf(['small', 'medium', 'large']),
  disabled: PropTypes?.bool,
  type: PropTypes?.oneOf(['button', 'submit', 'reset']),
  fullWidth: PropTypes?.bool,
  className: PropTypes?.string,
};

export default Button;